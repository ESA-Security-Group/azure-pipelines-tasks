% LOAD_ALL_ICESSN Load all NASA ATM ICESSN Greenland data for all campaigns between 1993-2016.
% 
% CHANGE PATHS ON LINES 10, 14 AND 153 TO THOSE SUITABLE FOR YOUR SYSTEM.
% 
% Joe MacGregor (NASA)
% Last updated: 08/31/17

clear

addpath('/Users/jamacgre/Documents/research/matlab/utils/icessn')

do_save                     = false;

load /Users/jamacgre/Documents/research/matlab/greenland/mat/gimp_proj gimp_proj

dir_atm                     = '/Users/jamacgre/Documents/data/atm_gr/';

% sort year names
name_year                   = dir(dir_atm);
name_year                   = {name_year.name}; % just need names
ind_good                    = false(1, length(name_year));
for ii = 1:length(name_year)
    if any(strcmp(name_year{ii}(1), {'1' '2'})) % directories that start with plausible years
        ind_good(ii)        = true;
    end
end
name_year                   = name_year(ind_good); % keep year directories
num_year                    = length(name_year);

% set icessn_ver here not because read_icessn can't handle it but because directory structures differ
icessn_ver                  = [ones(1, 14) (2 .* ones(1, (num_year - 14)))];

% initialize
[elev_surf, dist, dist_cen, lat, lon, name_day, name_seg, num_pt_removed, num_pt_used, num_seg, rms_fit, slope, slope_sn, slope_we, time_utc, track_id, x, y] ...
                            = deal(cell(1, num_year));
num_day                     = NaN(1, num_year);

for ii = 1:num_year
    
    disp(name_year{ii})
    dir_year                = [dir_atm name_year{ii} '/']; % current working directory (year)
    
    switch icessn_ver(ii)
        
        case 1 % v1
            
            % flight day names
            name_day{ii}    = dir(dir_year);
            
            if isempty(name_day{ii})
                continue
            end
            
            ind_good        = false(1, length(name_day{ii}));
            for jj = 1:length(name_day{ii})
                if (length(name_day{ii}(jj).name) < 8) % day directories are yyyymmdd (8 characters)
                    continue
                end
                if (name_day{ii}(jj).isdir && strcmp(name_day{ii}(jj).name(1:4), name_year{ii}(1:4))) % directory name is sane
                    ind_good(jj) ...
                            = true;
                end
            end
            name_day{ii}    = {name_day{ii}(ind_good).name};
            num_day(ii)     = length(name_day{ii});
            
            % initialize
            [elev_surf{ii}, dist{ii}, dist_cen{ii}, lat{ii}, lon{ii}, name_seg{ii}, num_pt_removed{ii}, num_pt_used{ii}, rms_fit{ii}, slope{ii}, slope_sn{ii}, slope_we{ii}, time_utc{ii}, track_id{ii}, x{ii}, y{ii}] ...
                            = deal(cell(1, num_day(ii)));
            num_seg{ii}     = NaN(1, num_day(ii));
            
            % segment names within each day
            for jj = 1:num_day(ii)
                name_seg{ii}{jj} ...
                            = dir([dir_atm name_year{ii} '/' name_day{ii}{jj} '/*nadir*seg']);
                name_seg{ii}{jj} ...
                            = {name_seg{ii}{jj}.name};
            end
            
        case 2 % v2
            
            % flight day names
            name_file_curr  = dir([dir_year '*.csv']);
            
            if isempty(name_file_curr)
                continue
            end
            
            name_file_curr  = {name_file_curr.name};
            num_file_curr   = length(name_file_curr);
            name_day_curr   = cell2mat(name_file_curr');
            [name_day_curr, ~, ind_day_curr] ...
                            = unique(name_day_curr(:, 8:15), 'rows'); % unique flight days
            num_day(ii)     = size(name_day_curr, 1);
            name_day{ii}    = cell(1, num_day(ii));
            for jj = 1:num_day(ii)
                name_day{ii}{jj} ...
                            = name_day_curr(jj, :);
            end
            
            % initialize
            [elev_surf{ii}, dist{ii}, dist_cen{ii}, lat{ii}, lon{ii}, name_seg{ii}, num_pt_removed{ii}, num_pt_used{ii}, rms_fit{ii}, slope{ii}, slope_sn{ii}, slope_we{ii}, time_utc{ii}, track_id{ii}, x{ii}, y{ii}] ...
                            = deal(cell(1, num_day(ii)));
            num_seg{ii}     = NaN(1, num_day(ii));
            
            % segment names within each day
            for jj = 1:num_day(ii)
                ind_file_curr ...
                            = find(jj == ind_day_curr);
                name_seg{ii}{jj} ...
                            = name_file_curr(ind_file_curr);
            end
            
    end % exit switch/case because no longer icessn version-dependent
    
    for jj = 1:num_day(ii)
        
        disp(name_day{ii}{jj})
        
        num_seg{ii}(jj)     = length(name_seg{ii}{jj}); % number of segments within flight day
        
        % initialize
        [elev_surf{ii}{jj}, dist_cen{ii}{jj}, lat{ii}{jj}, lon{ii}{jj}, num_pt_removed{ii}{jj}, num_pt_used{ii}{jj}, track_id{ii}{jj}, rms_fit{ii}{jj}, slope{ii}{jj}, slope_sn{ii}{jj}, slope_we{ii}{jj}, time_utc{ii}{jj}] ...
                            = deal(cell(1, num_seg{ii}(jj)));
        
        % extract data from each segment for current flight day
        for kk = 1:num_seg{ii}(jj)
            switch icessn_ver(ii)
                case 1
                    file_curr   = [dir_atm name_year{ii} '/' name_day{ii}{jj} '/' name_seg{ii}{jj}{kk}];
                case 2
                    file_curr   = [dir_atm name_year{ii} '/' name_seg{ii}{jj}{kk}];
            end
            [lon{ii}{jj}{kk}, lat{ii}{jj}{kk}, elev_surf{ii}{jj}{kk}, time_utc{ii}{jj}{kk}, slope_sn{ii}{jj}{kk}, slope_we{ii}{jj}{kk}, rms_fit{ii}{jj}{kk}, num_pt_used{ii}{jj}{kk}, num_pt_removed{ii}{jj}{kk}, dist_cen{ii}{jj}{kk}, track_id{ii}{jj}{kk}] ...
                            = read_icessn(file_curr);
        end
        
        % concatenate segments into one vector for current flight day
        [lon{ii}{jj}, lat{ii}{jj}, elev_surf{ii}{jj}, time_utc{ii}{jj}, slope_sn{ii}{jj}, slope_we{ii}{jj}, rms_fit{ii}{jj}, num_pt_used{ii}{jj}, num_pt_removed{ii}{jj}, dist_cen{ii}{jj}, track_id{ii}{jj}] ...
                            = deal([lon{ii}{jj}{:}], [lat{ii}{jj}{:}], [elev_surf{ii}{jj}{:}], [time_utc{ii}{jj}{:}], [slope_sn{ii}{jj}{:}], [slope_we{ii}{jj}{:}], [rms_fit{ii}{jj}{:}], [num_pt_used{ii}{jj}{:}], [num_pt_removed{ii}{jj}{:}], [dist_cen{ii}{jj}{:}], [track_id{ii}{jj}{:}]);
        
        % simple operations for each flight day
        [x{ii}{jj}, y{ii}{jj}] ...
                            = projfwd(gimp_proj, lat{ii}{jj}, lon{ii}{jj}); % EPSG:3413
        [x{ii}{jj}, y{ii}{jj}] ...
                            = deal((1e-3 .* x{ii}{jj}), (1e-3 .* y{ii}{jj})); % m to km
        dist{ii}{jj}        = [0 cumsum(sqrt((diff(x{ii}{jj}) .^ 2) + (diff(y{ii}{jj}) .^ 2)))]; % along-track distance
        slope{ii}{jj}       = sqrt((slope_sn{ii}{jj} .^ 2) + (slope_we{ii}{jj} .^ 2)); % total slope
    end
end

if do_save
    save /Users/jamacgre/Documents/research/matlab/greenland/mat/atm_icessn elev_surf dist dist_cen lat lon name_day name_seg name_year num_pt_removed num_pt_used num_seg num_day num_seg num_year rms_fit slope slope_sn slope_we time_utc track_id x y
end