function time_adj         = gps2utc(time_gps)
% GPS2UTC Determine number of leap seconds necessary for correction from GPS to UTC time.
% 
%   TIME_ADJ = GPS2UTC(TIME_GPS) returns the number of leap seconds
%   necessary for the correction based on a look-up table and the values of
%   TIME_GPS. These values are determined from:
%   https://confluence.qps.nl/display/KBE/UTC+to+GPS+Time+Correction#UTCtoGPSTimeCorrection-UTCtoGPSTimeConversionTable
%   and
%   http://maia.usno.navy.mil/ser7/tai-utc.dat
% 
%   NOTE THAT GPS2UTC AS CURRENTLY WRITTEN WILL RETURN NaN FOR ANY DATE
%   AFTER 31 DECEMBER 2017. VISIT THE ABOVE URLS TO DETERMINE SUITABLE LEAP
%   SECOND CORRECTIONS FOR PERIODS AFTER THAT DATE.
% 
%   Michael Studinger (NASA), Joe MacGregor (NASA)
%   Last updated: 08/31/17

if (nargin ~= 1)
    error('gps2utc:nargin', 'Numbers of arguments must be 1.')
end
if (~isnumeric(time_gps) || ~isvector(time_gps))
    error('gps2utc:time_gps', 'TIME_GPS must be a numeric vector.')
end
if (nargout > 1)
    error('gps2utc:nargout', 'Numbers of outputs must be 1.')
end

% lookup table of beginnings of leap second changes (year/month/day) and number of seconds (4th column)
time_adj_data               = [1990 1 1 6;
                               1991 1 1 7;
                               1992 7 1 8;
                               1993 7 1 9;
                               1994 7 1 10;
                               1996 1 1 11;
                               1997 7 1 12;
                               1999 1 1 13;
                               2006 1 1 14;
                               2009 1 1 15;
                               2012 7 1 16;
                               2015 7 1 17;
                               2017 1 1 18;
                               2018 1 1 NaN];

% identify vector range that time_gps falls within and lookup appropriate leap-second adjustment for each value
time_adj                    = time_adj_data(discretize(time_gps, datenum(time_adj_data(:, 1:3))), 4);

end