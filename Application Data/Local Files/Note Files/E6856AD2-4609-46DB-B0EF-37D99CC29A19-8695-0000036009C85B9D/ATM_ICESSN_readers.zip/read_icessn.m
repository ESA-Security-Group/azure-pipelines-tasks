function [lon, lat, elev_surf, time_utc, slope_sn, slope_we, rms_fit, num_pt_used, num_pt_removed, dist_cen, track_id] ...
                            = read_icessn(name_file, verbosity)
% READ_ICESSN Load NASA ATM ICESSN data.
% 
%   [LON,LAT,ELEV_SURF,TIME_UTC,SLOPE_SN,SLOPE_WE,RMS_FIT,NUM_PT_USED,NUM_PT_REMOVED,DIST_CEN,TRACK_ID] = READ_ICESSN(NAME_FILE,VERBOSITY)
%   
%   READ_ICESSN(NAME_FILE) returns all fields in version 1 (no extension)
%   or 2 (.csv) ICESSN file called NAME_FILE, which includes both path and
%   extension. READ_ICESSN determines which version the file is based on
%   its extension and patterns in file names.
% 
%   Output          Name                                                                                Units
%   
%   LAT             Latitude                                                                            decimal degrees
%   LON             Longitude                                                                           decimal degrees
%   ELEV_SURF       Surface elevation                                                                   meters above WGS84 ellipsoid
%   TIME_UTC        UTC time                                                                            days
%   SLOPE_SN        South-to-North slope                                                                dimensionless
%   SLOPE_WE        West-to-East slope                                                                  dimensionless
%   RMS_FIT         RMS fit of the ATM data to the plane                                                centimeters
%   NUM_PT_USED     Number of points used in estimating the plane parameters                            dimensionless
%   NUM_PT_REMOVED  Number of points removed in estimating the plane parameters                         dimensionless
%   DIST_CEN        Distance of the center of the block from the centerline of the aircraft trajectory  meters
%   TRACK_ID        Track identifier (numbered 1..n, starboard to port, where 0=nadir)                  dimensionless
% 
%   READ_ICESSN(NAME_FILE,VERBOSITY) also echoes information about the
%   loaded file if VERBOSITY=TRUE.
% 
%   Michael Studinger (NASA), Joe MacGregor (NASA)
%   Last updated: 09/09/2017

if ((nargin == 0) || (nargin > 2))
    error('read_icessn:nargin', 'Number of arguments must be 1 or 2.')
end
if (~ischar(name_file) || ~isvector(name_file))
    error('read_icessn:name_file1', 'NAME_FILE must be a vector string.')
end
if ~exist(name_file, 'file')
    error('read_icessn:name_file2', 'NAME_FILE does not exist.')
end
if (nargin == 2)
    if (~islogical(verbosity) || ~isscalar(verbosity))
        error('read_icessn:verbosity', 'VERBOSITY must be a scalar logical.')
    end
end
if (nargout > 11)
    error('read_icessn:nargout', 'Number of outputs must be less than 11.')
end

% break out file name parts
[~, name_file_noext, ext]   = fileparts(name_file);

% identify ICESSN version
if (strncmp(name_file_noext,'ILATM2_',7) && strcmp(ext, '.csv'))            % ILATM2_20131126_195058_smooth_nadir3seg_50pt.csv
    icessn_ver              = 2;
elseif (strncmp(name_file_noext,'BLATM2_',7) && strcmp(ext, ''))            % BLATM2_010520_110524_smooth_nadir5seg
    icessn_ver              = 1;
elseif (strcmp(name_file_noext(14:26),'_smooth_nadir') && strcmp(ext, ''))  % 010520_110524_smooth_nadir5seg (some version 1 files)
    icessn_ver              = 0;                                            % 12345678901234567890123456 
else
    error('read_icessn:icessn_version', '\n\tERROR: Unable to determine ICESSN version from file name. Abort.')
end

% read ATM data from ICESSN file
fid                         = fopen(name_file, 'r');
switch icessn_ver
    case 0
        data                = textscan(fid, '%f %f %f %f %f %f %f %d %d %f %d');
    case 1
        data                = textscan(fid, '%f %f %f %f %f %f %f %d %d %f %d');
    case 2
        data                = textscan(fid, '%f %f %f %f %f %f %f %d %d %f %d', 'headerlines', 10, 'delimiter', ','); % to make output compatible with version 1
    otherwise
        error('read_icessn:icessn_version', '\n\tERROR: ICESSN version not valid. Abort.')
end
fclose(fid);

% break out data into row vectors
time_gps                    = cell2mat(data(1))';
lat                         = cell2mat(data(2))';
lon                         = cell2mat(data(3))';
elev_surf                   = cell2mat(data(4))';
slope_sn                    = cell2mat(data(5))';
slope_we                    = cell2mat(data(6))';
rms_fit                     = cell2mat(data(7))';
num_pt_used                 = cell2mat(data(8))';
num_pt_removed              = cell2mat(data(9))';
dist_cen                    = cell2mat(data(10))';
track_id                    = cell2mat(data(11))';

% get year/month/day from filename
sec_per_day                 = 60 * 60 * 24;
switch icessn_ver
    case 0
        year                = str2double(name_file_noext(1:2));
        if (year > 90)
            year            = year + 1900;
        else
            year            = year + 2000;
        end
        month               = str2double(name_file_noext(3:4));
        day                 = str2double(name_file_noext(5:6));
        time_adj            = gps2utc(datenum(year, month, day)); % number of leap seconds to adjust by
        time_utc            = datenum(year, month, day) + (time_gps ./ sec_per_day) - (time_adj / sec_per_day);
    case 1
         year                = str2double(name_file_noext(8:9));
        if (year > 90)
            year            = year + 1900;
        else
            year            = year + 2000;
        end
        month               = str2double(name_file_noext(10:11));
        day                 = str2double(name_file_noext(12:13));
        time_adj            = gps2utc(datenum(year, month, day)); % number of leap seconds to adjust by
        time_utc            = datenum(year, month, day) + (time_gps ./ sec_per_day) - (time_adj / sec_per_day);
    case 2
        year                = str2double(name_file_noext(8:11));
        month               = str2double(name_file_noext(12:13));
        day                 = str2double(name_file_noext(14:15));
        time_utc            = datenum(year, month, day) + (time_gps ./ sec_per_day);
end

% check if date conversion makes sense to cover potential changes in file names
if (time_utc(1) <= datenum(1993,06,01) || time_utc >= datenum(now))
        error('read_icessn:time_conversion', '\n\tERROR: The year, month, and day extracted from the file name are outside the valid range for available ICESSN files. Abort.')
end

% echo information concerning flight and UTC time sampled
if (nargin == 2)
    if verbosity
        fprintf('\n-----------------------------------------------------------------------\n');
        fprintf('Processed file: %s\n', name_file_noext);
        fprintf('UTC start: %s  |  UTC end:\t%s\n', datestr(time_utc(1), 'yyyy/mm/dd HH:MM:SS.FFF'), datestr(time_utc(end),'yyyy/mm/dd HH:MM:SS.FFF'));
        fprintf('Length (hh:mm:ss): %s         |  N platelets: %d\n', datestr((time_utc(end) - time_utc(1)), 'HH:MM:SS'), length(lat));
        fprintf('\n-----------------------------------------------------------------------\n');
    end
end

end